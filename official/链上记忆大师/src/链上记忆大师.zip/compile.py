from solcx import compile_source
import json

for i in 1, 2, 3:
    compiled_sol = compile_source(open(f'challenge{i}.sol').read(), output_values=['abi', 'bin'])
    contract_interface = compiled_sol['<stdin>:Challenge']
    bytecode = contract_interface['bin']
    abi = contract_interface['abi']
    json.dump((bytecode, abi), open(f'contract{i}.json', 'w'))
