from web3 import Web3
from web3.middleware import geth_poa_middleware
import os
import json
import time
import shutil

challenge_id = int(input('The challenge you want to play (1 or 2 or 3): '))
assert challenge_id == 1 or challenge_id == 2 or challenge_id == 3

player_bytecode = bytes.fromhex(input('Player bytecode: '))

print('Launching geth...')
shutil.copytree('/data', '/dev/shm/geth')
os.system('geth --datadir /dev/shm/geth --nodiscover --mine --unlock 0x2022af4DCbb9dA7F41cBD3dD8CdB4134D4e6DDe6 --password password.txt --verbosity 0 --datadir.minfreedisk 0 &')
time.sleep(2)
w3 = Web3(Web3.IPCProvider('/dev/shm/geth/geth.ipc'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
w3.eth.default_account = w3.eth.accounts[0]
w3.geth.personal.unlock_account(w3.eth.default_account, open('password.txt').read().strip())
print('Deploying challenge contract...')
bytecode, abi = json.load(open(f'contract{challenge_id}.json'))
Challenge = w3.eth.contract(abi=abi, bytecode=bytecode)
tx_hash = Challenge.constructor().transact()
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print('Challenge contract address:', tx_receipt.contractAddress)
challenge = w3.eth.contract(address=tx_receipt.contractAddress, abi=abi)
print('Deploying player contract...')
tx_hash = w3.eth.send_transaction({'to': None, 'data': player_bytecode})
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print('Player contract address:', tx_receipt.contractAddress)
for i in range(10):
    print(f'Testing {i + 1}/10...')
    if challenge_id == 2:
        n = int.from_bytes(os.urandom(2), 'big')
    else:
        n = int.from_bytes(os.urandom(32), 'big')
    print(f'n = {n}')
    if challenge.functions.test(tx_receipt.contractAddress, n).call():
        print('Test passed!')
    else:
        print('Test failed!')
        exit(-1)
print(open(f'flag{challenge_id}').read())
