#!/bin/sh

export SHELL=bash
export TERM=xterm256-color
stty rows 33 columns 120
python3 BP.py