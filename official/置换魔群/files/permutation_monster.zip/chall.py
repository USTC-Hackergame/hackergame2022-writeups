from Answers import Sporadic_Group_Answers, Sporadic_Group_Orders, Max_Order_of_An
from random import randint

Sporadic_Group_Orders = {
    "M11": 7920,
    "M12": 95040,
    "M22": 443520,
    "M23": 10200960,
    "M24": 244823040,
    "J1": 175560,
    "H-S": 44352000,
    "J2": 604800,
    "McL": 898128000,
    "Suz": 448345497600,
    "J3": 50232960,
    "Co1": 4157771806543360000,
    "Co2": 42305421312000,
    "Co3": 495766656000,
    "He": 4030387200,
    "Fi22": 64561751654400,
    "Fi23": 4089470473293004800,
    "Fi24": 1255205709190661721292800,
    "Ly": 51765179004000000,
    "Ru": 145926144000,
    "ON": 460815505920,
    "F3": 90745943887872000,
    "F5": 272030912000000,
    "F2": 4154781481226426191177580544000000,
    "F1": 808017424794512875886459904961710757005754368000000000,
    "J4": 86775571046077562880
}


def chall_1():
    # chall 1
    msg = """
    To embed all the 26 sporadic groups into permutation group, you need to find the smallest n such that 
    there exists a permutation A with sporadic group's order: O_i which means A^O_i == (1,2,..,n) (identity permutation).
    """
    print(msg)
    print("Enjoy your math time!")

    for item in Sporadic_Group_Orders:
        print(f"[+] group : {item} , order: {Sporadic_Group_Orders[item]}")
        ans = int(input("> your answer: "))
        if ans == Sporadic_Group_Answers[item]:
            print("God job!")
            continue
        else:
            print("Try again.")
            return
    print(open("./flag1", "r").read())


def chall_2():
    # chall 2
    print("How about the max order of an element in permutation group A_n ?")
    print("Some easy cases.")
    for _ in range(5):
        chall_num = randint(2, 2**6)
        print(f"[+] your challenge number: {chall_num}")
        ans = int(input("> your answer: "))
        if ans == Max_Order_of_An[chall_num]:
            print("God job!")
        else:
            print("Try again.")
            return

    print("Try hard cases and be fast!")
    for _ in range(10):
        chall_num = randint(2, 100000)
        print(f"[+] your challenge number: {chall_num}")
        ans = int(input("> your answer: "))
        if ans == Max_Order_of_An[chall_num]:
            print("God job!")
        else:
            print("Try again.")
            return
    print(open("./flag2", "r").read())


banner = """
> 1. challenge 1
> 2. challenge 2
> others. exit()
"""

while True:
    print("Welcome to the permutation-monster group challenge!")
    print(banner)
    try:
        choice = int(input("> your choice (1 or 2): "))
    except:
        print("Must be a digit number")
        continue
    if choice == 1:
        chall_1()
    elif choice == 2:
        chall_2()
    else:
        print("Byebye")
        exit()
