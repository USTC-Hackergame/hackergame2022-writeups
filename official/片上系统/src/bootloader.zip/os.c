volatile int* uart_tx			= (int*) 0x93000000;
volatile int* uart_tx_done		= (int*) 0x93000008;
volatile int* uart_rx_reset		= (int*) 0x93000004;
volatile int* uart_rx_new		= (int*) 0x93000004;
volatile int* uart_rx_data		= (int*) 0x93000000;
volatile int* gpio_ctrl			= (int*) 0x92000000;
volatile int* video_base		= (int*) 0x94000000;

char uart_getchar()
{
	while(! *uart_rx_new);
	char c = *uart_rx_data;
	*uart_rx_reset = 1;
	return c;
	/*return *uart_rx_data;*/
}
void uart_putchar(char c)
{
	while(! *uart_tx_done);
	*uart_tx = c;
	while(! *uart_tx_done);
}
void uart_putstr(const char* str)
{
	int n = 0;
	while(str[n]) uart_putchar(str[n++]);
}
void uart_puthex(unsigned int hex)
{
	int i, x;
	for (i = 7; i >= 0; i--) {
		x = (hex >> (i*4)) % 0x10;
		uart_putchar(x + (x < 10 ? '0' : 'a' - 10));
	}
}
void os()
{
	*uart_rx_reset = 1;
	int on = 0xffffffff;
	gpio_ctrl[6] = on;
	gpio_ctrl[7] = on;
	gpio_ctrl[8] = on;
	gpio_ctrl[9] = on;
	uart_putstr("LED: ON\r\n");

	int mem_start = 0x20100000;
	int i;
	for(i = 0; i < 0x4000; i+=4) {
		int* addr_to_test = (int *)(mem_start + i);
		*addr_to_test = i;
	}
	uart_putstr("Memory: ");
	for(i = 0; i < 0x4000; i+=4) {
		int* addr_to_test = (int *)(mem_start + i);
		int readback = *addr_to_test;
		if (readback != i) {
			gpio_ctrl[6] = 0;
			gpio_ctrl[7] = 0;
			gpio_ctrl[8] = 0;
			gpio_ctrl[9] = 0;
			while(1);
		}
	}
	uart_putstr("OK\r\n");

	int j;
	for(j = 0; j < 38399; j++) video_base[j] = 0x0;
	video_base[4177920] = 0x0;
	int base_color_arr[] = {0x00, 0x03, 0xe0, 0x1c, 0x1f, 0xe3, 0xfc, 0xff};
	for(i = 0; i < 320; i++) {
		for(j = 0; j < 120; j++) {
			int base_color_idx = i / (320/8);
			int clr = (j < 60 ? base_color_arr[base_color_idx] : i*2+j*4);
			clr = clr % 0x100;
			video_base[i*120+j] = clr + (clr<<8) + (clr<<16) + (clr<<24);
		}
	}
	uart_putstr("Video outputed\r\n");
	uart_putstr("flag{");
	uart_puthex(&uart_puthex);
	uart_puthex(0xdeadbeef ^ (unsigned int)&os);
	uart_puthex(base_color_arr[2]);
	uart_putstr("}\r\n");

	while(1);
}
