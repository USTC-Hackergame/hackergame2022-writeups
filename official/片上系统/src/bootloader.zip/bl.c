volatile int* sd_cache_base		= (int*) 0x96000000;
volatile int* sd_address		= (int*) 0x96001000;
volatile int* sd_do_read		= (int*) 0x96001004;
volatile int* sd_do_write		= (int*) 0x96001008;
volatile int* sd_ncd			= (int*) 0x96002000;
volatile int* sd_ready			= (int*) 0x96002010;
volatile int* sd_cache_dirty	= (int*) 0x96002014;
volatile int* ram_os			= (int*) 0x20001000;
void sd_bl()
{
	int sector = 1;
	for (; sector <= 6; sector++) {
		while(! *sd_ready);
		*sd_address = sector;
		*sd_do_read = 0x01;
		while(! *sd_ready);
		int i = 0;
		for (i = 0; i < 128; i++)
			ram_os[i + ((sector-1) * 128)] = sd_cache_base[i];
	}
	asm("li t0, 0x20001000; jr t0;" ::: "t0");
}
