#!/bin/bash

# install pwntools first
python3 -m pip install pwntools

# run exp
python3 exp.py $ip $port